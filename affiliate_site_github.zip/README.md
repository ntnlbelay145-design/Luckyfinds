# אתר שיווק שותפים - GitHub Pages

### איך להעלות:
1. פתחי חשבון ב-[GitHub](https://github.com).
2. צרי Repository חדש בשם `affiliate-site` (או כל שם אחר).
3. העלי לתוכו את כל הקבצים מהתיקייה הזו.
4. לכי ל-Settings → Pages → תחת 'Source' בחרי `main branch /docs folder`.
5. האתר יופיע בכתובת: `https://yourusername.github.io/affiliate-site/`

---
בהמשך אפשר להחליף את הטקסטים, להוסיף פוסטים ותמונות, ולהכניס קישורי שותפים אמיתיים.
